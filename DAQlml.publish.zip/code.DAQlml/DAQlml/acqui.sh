#!/bin/bash

fout=test.nc
pathout=./test/

fout=$1
pathout=$2
bin=.

#compile parameters
ncgen -o parameters.nc parameters.cdl;
#info on DAQlml program
$bin/DAQlml -h; 
#acquire
$bin/DAQlml --buffer --fo $fout --show 1
#save in pathout directory
mv $fout $pathout
name=`basename $fout .nc`
cp parameters.cdl parameters_$name.cdl  
mv parameters_$name.cdl  $pathout
