var DAQloop_8h =
[
    [ "LOOP_USLEEP_TIME", "DAQloop_8h.html#ad6331b4479d31362fe10622966aa9a7d", null ],
    [ "sample_data_buffer", "DAQloop_8h.html#a2d58e5ae6b7275b66f5e1d2547dee82b", null ],
    [ "sample_data_point", "DAQloop_8h.html#ab06adc95508cef0ec354cdaad2dc3a1a", null ]
];