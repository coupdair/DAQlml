var files =
[
    [ "DAQcomedi.h", "DAQcomedi_8h.html", "DAQcomedi_8h" ],
    [ "DAQdata.h", "DAQdata_8h.html", "DAQdata_8h" ],
    [ "DAQloop.h", "DAQloop_8h.html", "DAQloop_8h" ],
    [ "doxygen.user_page.h", "doxygen_8user__page_8h.html", null ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ]
];