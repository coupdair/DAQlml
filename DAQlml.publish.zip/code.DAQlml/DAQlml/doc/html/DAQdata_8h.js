var DAQdata_8h =
[
    [ "load_data", "DAQdata_8h.html#a476cf2c129e5c15fa763b35e7f7d7156", null ],
    [ "load_data", "DAQdata_8h.html#ae1ea15ba6c7200672e48ebb5ca3805e0", null ],
    [ "load_data_attribute", "DAQdata_8h.html#aca3e3459584f439f86ca79f2f02d739a", null ],
    [ "save_data", "DAQdata_8h.html#a79858a0eef14342272354daef3df5f3d", null ]
];