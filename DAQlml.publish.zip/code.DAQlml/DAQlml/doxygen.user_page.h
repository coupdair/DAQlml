//doxygen DAQlml user page
/*! \page pageUser DAQlml user
  This page explain how to use DAQlml, e.g. how to record 3 channels.

\todo 1. comedi www link in main page (i.e. main.cpp)
\todo 2. ncview graph (from PCacq: yum install ncview)

  table of contents:
  \li \ref sectionHelp
  \code DAQlml --help \endcode 
  \li \ref sectionUser
  \li \ref subsecCDL
  \code gedit parameters.cdl & \endcode
  \li \ref subsecDAQ
  \code ncgen -o parameters.nc parameters.cdl; DAQlml --buffer true \endcode 
  \li \ref subsecNC
  \code ncdump -h data.nc; ncview data.nc & \endcode 

  \section sectionHelp get help
  Get help command line options using:
  \li <code>-h</code>
  \li <code>--help</code>

  \li screenshot after calling <code>DAQlml --help</code>:
  \image html doxygen.help.png


  \section sectionUser get data
  \subsection subsecCDL setup DAQlml (CDL)

  A parameter file is used to configure recording, e.g. sampling rate.
  DAQlml use NetCDF text file, i.e. .cdl, for this purpose.

  \warning use <code>ncgen</code> program (from NetCDF OpenSource project that is a needed library)
           to compile text to binary format (i.e. .CDL to .NC format).

  \li write desired values in the <code>parameters.cdl</code> file, using any text editor
      e.g. \code gedit parameters.cdl \endcode see an example of file content below.
  \li convert <code>parameters.cdl</code> to <code>parameters.nc</code> using <code>ncgen</code>,
      e.g. \code ncgen -o parameters.nc parameters.cdl \endcode

  \li content of parameter file in CDL format i.e. text format (e.g. <code>nano parameters.cdl</code>):
  \verbinclude "parameters.cdl"

  Each value is set on a line that begins with <code>acquisition:</code> as CDL is segmented language
  e.g. <code>acquisition:number_of_samples = 500;</code>.
  It does also end with a ';' (like C/C++ syntax).
  One can specify: voltage range, channel indexes, sampling rate, number of sample to record and finally channel names used for storage.

  \note NetCDF language: <code>acquisition</code> is called variable and <code>acquisition:*</code> attribute of this variable.
                         <code>acquisition</code> represents the recording part of DAQlml. Its attributes are how it should behave.

  \subsection subsecDAQ run DAQlml

  Record 3 channels with the previous parameter file <code>parameters.nc</code>,
  using the following command:

  \code
    DAQlml --fp parameters.nc --buffer true
  \endcode

  To see record plot, right after recording, add <code>--show 1</code> command line option:

  \code
    DAQlml --fp parameters.nc --buffer true --show 1
  \endcode

  \note DAQlml will plot first channel in red, then second one in green and 3rd in blue against time (actually, sample index).

  \li screenshot after recording 3 channels:
  \image html doxygen.GUI.png

  \note channel names should be set on line <code>acquisition:channel_name</code> in <code>parameters.cdl</code>
        prior to both compilation of .CDL to .NC and running program.
        Number of names must match to number of channels (see indexes that are set on line <code>acquisition:channels</code>).

  \subsection subsecNC  see NetCDF data

  Use for example <code>ncdump</code> (header as text) or <code>ncview</code> (data as plot) from other OpenSource projects
  to see recorded data.

  \li \b NCdump: output after calling: \code ncdump -h data.nc \endcode with <code>-h</code> for Header:
  \note output file name was set using <code>--fo</code> command line option (or default name).

  \verbinclude "doxygen.dump.txt"

  To comment this output:
  \li variable <code>A01</code> corresponds to first recorded channel.
      It is an \b array of <code>time</code> \b dimension (e.g. 500 samples)
  and has \b floating \b point values (i.e. float type).
  \li the time axis, that is in second, is also an array of the same dimension (see <code>float time(time) ;</code>).
  \li moreover, it is also called <code>time</code>.
      But this \b variable (i.e. array) is different than <code>time</code> \b dimension
      (i.e. single value, see <code>dimensions: time = 500 ;</code>).

  \li \b NCview: data plot displayed by calling: \code ncview data.nc \endcode and selecting by mouse <code>A01</code> variable:
  \verbinclude "doxygen.ncview.png"

  \note plot \e A01 vs. \e time with time axis in second unit, as \e time \b variable have the same name as \e time \b dimension.
        This is a ncview feature, that DAQlml use by just creating \e time variable.

*/
