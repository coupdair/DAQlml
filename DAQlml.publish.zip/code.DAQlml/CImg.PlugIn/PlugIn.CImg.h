#ifndef PLUGIN_CIMG
#define PLUGIN_CIMG

//#include "../LaVision/PlugIn.CImg.LaVision.h"
//#include "../raw/PlugIn.CImg.raw.h"
//#include "../PCO/PlugIn.CImg.PCO.h"
//#include "../Hiris/PlugIn.CImg.Hiris.h"

#include "../CImg.PlugIn/PlugIn.CImg.sprite.h"

#endif/*PLUGIN_CIMG*/
