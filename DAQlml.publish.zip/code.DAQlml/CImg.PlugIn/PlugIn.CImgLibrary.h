#ifndef PLUGIN_CIMGLIBRARY
#define PLUGIN_CIMGLIBRARY

/* to add to CImg.h @ "// End of the 'cimg' namespace"
#ifdef cimgnamespace_plugin
#include cimgnamespace_plugin
#endif
*/

#include "../raw/PlugIn.CImgLibrary.raw.h"
#include "../CImg.PlugIn/PlugIn.CImgLibrary.cimg_for.h"

#endif/*PLUGIN_CIMGLIBRARY*/
